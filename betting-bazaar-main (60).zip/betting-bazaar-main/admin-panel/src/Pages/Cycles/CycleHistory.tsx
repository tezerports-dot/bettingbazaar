// GOVERNANCE: Read 04-GOVERNANCE.md before editing this file. (See sec.0 for mandatory pre-edit checklist.)
import React, { useEffect, useState } from 'react';
import { History, Download } from 'lucide-react';
import { DataTable } from '../../components/DataTable';
import { StatusBadge } from '../../components/StatusBadge';
import { SearchBar } from '../../components/SearchBar';
import { DateRangePicker } from '../../components/DateRangePicker';
import { Modal } from '../../components/Modal';
import { usePagination } from '../../hooks/usePagination';
import { useDebounce } from '../../hooks/useDebounce';
import { formatters } from '../../utils/formatters';
import api from '../../services/api';
import type { Cycle } from '../../types';
import toast from 'react-hot-toast';

export const CycleHistory: React.FC = () => {
  const [cycles, setCycles] = useState<Cycle[]>([]);
  const [total, setTotal] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState('ALL');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [selectedCycle, setSelectedCycle] = useState<Cycle | null>(null);

  const { page, limit, setPage } = usePagination();
  const debouncedSearch = useDebounce(search);

  useEffect(() => { loadCycles(); }, [page, debouncedSearch, typeFilter, startDate, endDate]);

  const loadCycles = async () => {
    setIsLoading(true);
    try {
      const response = await api.cycles.getHistory(page, limit, typeFilter === 'ALL' ? undefined : typeFilter);
      if (response.success && response.data) {
        setCycles(response.data);
        setTotal(response.pagination?.total || 0);
      }
    } catch (error) {
      toast.error('Failed to load cycle history');
    } finally {
      setIsLoading(false);
    }
  };

  // Net Revenue = loser bets - winner payouts
  // = (realPool - 2 × winnerSideBets) = realPool - totalPaidOut = netProfit stored in DB
  // We also show the loser/winner split visually
  const getNetRevenue = (cycle: Cycle) => cycle.netProfit || 0;

  const getLoserWinnerSplit = (cycle: Cycle) => {
    if (!cycle.winner) return { loserBets: 0, winnerBets: 0 };
    const loserBets  = cycle.winner === 'DELHI'  ? (cycle.realBombay || 0) : (cycle.realDelhi || 0);
    const winnerBets = cycle.winner === 'DELHI'  ? (cycle.realDelhi  || 0) : (cycle.realBombay || 0);
    return { loserBets, winnerBets };
  };

  const getCycleTypeBadge = (type: string) =>
    type === '30_MIN' ? (
      <span className="px-2 py-1 rounded text-xs font-medium bg-blue-500/20 text-blue-500">30 MIN</span>
    ) : (
      <span className="px-2 py-1 rounded text-xs font-medium bg-purple-500/20 text-purple-500">FULL DAY</span>
    );

  const columns = [
    {
      key: 'cycleId', label: 'Cycle ID',
      render: (cycle: Cycle) => (
        <div>
          <p className="font-mono font-semibold text-xs text-gold-400">{cycle.cycleId}</p>
          {getCycleTypeBadge(cycle.type)}
        </div>
      ),
    },
    {
      key: 'period', label: 'Period',
      render: (cycle: Cycle) => (
        <div className="text-xs">
          <p className="text-gray-300">▶ {formatters.datetime(new Date(cycle.startTime))}</p>
          <p className="text-gray-500">⏹ {formatters.datetime(new Date(cycle.endTime))}</p>
        </div>
      ),
    },
    {
      key: 'pools', label: 'Real Pools',
      render: (cycle: Cycle) => (
        <div className="text-sm">
          <p><span className="text-gray-400">Delhi:</span> <span className="text-red-400">{formatters.currency(cycle.realDelhi || 0)}</span></p>
          <p><span className="text-gray-400">Bombay:</span> <span className="text-blue-400">{formatters.currency(cycle.realBombay || 0)}</span></p>
        </div>
      ),
    },
    {
      key: 'winner', label: 'Winner',
      render: (cycle: Cycle) => (
        cycle.winner ? (
          <span className={`font-bold text-sm ${cycle.winner === 'DELHI' ? 'text-red-400' : 'text-blue-400'}`}>
            {cycle.winner}
          </span>
        ) : <span className="text-gray-500">-</span>
      ),
    },
    {
      key: 'revenue', label: 'Net Revenue',
      render: (cycle: Cycle) => {
        const rev = getNetRevenue(cycle);
        return (
          <span className={`font-semibold text-sm ${rev > 0 ? 'text-green-400' : rev < 0 ? 'text-red-400' : 'text-gray-500'}`}>
            {cycle.winner ? formatters.currency(rev) : '-'}
          </span>
        );
      },
    },
    {
      key: 'payout', label: 'Paid Out',
      render: (cycle: Cycle) => (
        <span className="text-orange-400 font-medium text-sm">
          {cycle.totalPaidOut ? formatters.currency(cycle.totalPaidOut) : '-'}
        </span>
      ),
    },
    {
      key: 'status', label: 'Status',
      render: (cycle: Cycle) => <StatusBadge status={cycle.status} type="cycle" />,
    },
    {
      key: 'actions', label: '',
      render: (cycle: Cycle) => (
        <button onClick={() => setSelectedCycle(cycle)} className="text-xs text-gold-400 hover:underline">
          Detail
        </button>
      ),
    },
  ];

  const totalNetRevenue = cycles.reduce((sum, c) => sum + getNetRevenue(c), 0);
  const totalPaidOut    = cycles.reduce((sum, c) => sum + (c.totalPaidOut || 0), 0);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold mb-2">Cycle History</h1>
          <p className="text-gray-400">Past cycle results — Net Revenue = Loser Bets − Winner Payouts</p>
        </div>
        <button className="btn-secondary flex items-center">
          <Download size={16} className="mr-2" /> Export CSV
        </button>
      </div>

      <div className="card space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="md:col-span-2">
            <SearchBar value={search} onChange={setSearch} placeholder="Search by Cycle ID..." />
          </div>
          <select value={typeFilter} onChange={(e) => setTypeFilter(e.target.value)} className="input">
            <option value="ALL">All Types</option>
            <option value="30_MIN">30-Min Cycles</option>
            <option value="FULL_DAY">Full Day Cycles</option>
          </select>
        </div>
        <DateRangePicker startDate={startDate} endDate={endDate} onStartDateChange={setStartDate} onEndDateChange={setEndDate} />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="card"><p className="text-sm text-gray-400 mb-1">Total Cycles</p><p className="text-2xl font-bold">{total}</p></div>
        <div className="card"><p className="text-sm text-gray-400 mb-1">30-Min</p><p className="text-2xl font-bold text-blue-500">{cycles.filter(c => c.type === '30_MIN').length}</p></div>
        <div className="card"><p className="text-sm text-gray-400 mb-1">Total Paid Out</p><p className="text-2xl font-bold text-orange-400">{formatters.currency(totalPaidOut)}</p></div>
        <div className="card"><p className="text-sm text-gray-400 mb-1">Net Revenue</p><p className={`text-2xl font-bold ${totalNetRevenue >= 0 ? 'text-green-400' : 'text-red-400'}`}>{formatters.currency(totalNetRevenue)}</p></div>
      </div>

      {/* Revenue formula explanation */}
      <div className="bg-dark-800 border border-dark-600 rounded-lg p-4 text-sm">
        <p className="font-semibold text-gray-300 mb-1">How Net Revenue is calculated per cycle:</p>
        <p className="text-gray-400">
          Net Revenue = <span className="text-red-400">Loser Side Real Bets</span> − <span className="text-blue-400">Winner Side Real Bets</span>{' '}
          = Real Pool Total − Total Paid Out (2×)
        </p>
        <p className="text-gray-500 text-xs mt-1">Phantom bets are never counted. Phantom bets always lose and are excluded from payouts.</p>
      </div>

      <div className="card">
        <DataTable data={cycles} columns={columns} currentPage={page} totalPages={Math.ceil(total / limit)} onPageChange={setPage} isLoading={isLoading} />
      </div>

      {/* Cycle Detail Modal */}
      {selectedCycle && (
        <Modal isOpen={!!selectedCycle} onClose={() => setSelectedCycle(null)} title="Cycle Detail" size="lg">
          <div className="space-y-5">
            {/* Identity */}
            <div className="bg-dark-700 rounded-lg p-4">
              <p className="text-xs text-gray-400 mb-1">Unique Cycle ID</p>
              <p className="font-mono font-bold text-gold-400 text-lg">{selectedCycle.cycleId}</p>
              <div className="flex gap-2 mt-2">{getCycleTypeBadge(selectedCycle.type)} <StatusBadge status={selectedCycle.status} type="cycle" /></div>
            </div>

            {/* Timestamps */}
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-dark-700 rounded-lg p-3">
                <p className="text-xs text-gray-400 mb-1">▶ Started</p>
                <p className="text-sm font-medium">{formatters.datetime(new Date(selectedCycle.startTime))}</p>
              </div>
              <div className="bg-dark-700 rounded-lg p-3">
                <p className="text-xs text-gray-400 mb-1">⏹ Ended</p>
                <p className="text-sm font-medium">{formatters.datetime(new Date(selectedCycle.endTime))}</p>
              </div>
            </div>

            {/* Real pools breakdown */}
            <div>
              <p className="text-sm font-semibold text-gray-300 mb-2">Real User Bets (no phantom)</p>
              <div className="grid grid-cols-2 gap-4">
                <div className={`p-4 rounded-lg border ${selectedCycle.winner === 'DELHI' ? 'bg-green-500/10 border-green-500/30' : 'bg-red-500/10 border-red-500/30'}`}>
                  <p className="text-xs text-gray-400 mb-1">DELHI {selectedCycle.winner === 'DELHI' ? '🏆 Winner' : '❌ Loser'}</p>
                  <p className="text-2xl font-bold text-red-400">{formatters.currency(selectedCycle.realDelhi || 0)}</p>
                </div>
                <div className={`p-4 rounded-lg border ${selectedCycle.winner === 'BOMBAY' ? 'bg-green-500/10 border-green-500/30' : 'bg-red-500/10 border-red-500/30'}`}>
                  <p className="text-xs text-gray-400 mb-1">BOMBAY {selectedCycle.winner === 'BOMBAY' ? '🏆 Winner' : '❌ Loser'}</p>
                  <p className="text-2xl font-bold text-blue-400">{formatters.currency(selectedCycle.realBombay || 0)}</p>
                </div>
              </div>
            </div>

            {/* Phantom pools (info only) */}
            <div>
              <p className="text-sm font-semibold text-gray-400 mb-2">Phantom Bets (always lose, not counted in revenue)</p>
              <div className="grid grid-cols-2 gap-4">
                <div className="p-3 bg-dark-800 rounded-lg">
                  <p className="text-xs text-gray-500">Delhi Phantom</p>
                  <p className="font-medium text-gray-500">{formatters.currency(selectedCycle.phantomDelhi || 0)}</p>
                </div>
                <div className="p-3 bg-dark-800 rounded-lg">
                  <p className="text-xs text-gray-500">Bombay Phantom</p>
                  <p className="font-medium text-gray-500">{formatters.currency(selectedCycle.phantomBombay || 0)}</p>
                </div>
              </div>
            </div>

            {/* Net Revenue calculation */}
            {selectedCycle.winner && (
              <div className="bg-gold-500/10 border border-gold-500/30 rounded-lg p-4">
                <p className="text-sm font-semibold text-gold-400 mb-3">Net Revenue Breakdown</p>
                {(() => {
                  const { loserBets, winnerBets } = getLoserWinnerSplit(selectedCycle);
                  const netRev = getNetRevenue(selectedCycle);
                  return (
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-400">Loser Side Bets ({selectedCycle.winner === 'DELHI' ? 'BOMBAY' : 'DELHI'}):</span>
                        <span className="text-green-400 font-medium">{formatters.currency(loserBets)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">Winner Bets ({selectedCycle.winner}) × 2 paid out:</span>
                        <span className="text-red-400 font-medium">− {formatters.currency(selectedCycle.totalPaidOut || winnerBets * 2)}</span>
                      </div>
                      <div className="flex justify-between pt-2 border-t border-dark-600">
                        <span className="font-semibold text-gray-200">Net Revenue:</span>
                        <span className={`font-bold text-lg ${netRev >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                          {formatters.currency(netRev)}
                        </span>
                      </div>
                    </div>
                  );
                })()}
              </div>
            )}
          </div>
        </Modal>
      )}
    </div>
  );
};
